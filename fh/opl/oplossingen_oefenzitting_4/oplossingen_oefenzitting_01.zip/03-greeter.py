first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")

greeting_message = "Welcome " + first_name + " " + last_name + "!"

print(greeting_message)
