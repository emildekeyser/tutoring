row_plus = "+--+--+--+"
row_line = "|  |  |  |"

print(row_plus)
print(row_line)
print(row_plus)
print(row_line)
print(row_plus)
print(row_line)
print(row_plus)
