import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class VODSystemTest
{
	Connection c = null;

	@Before
	public void setUp() throws Exception
	{
		try 
		{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:VODSystem.db");
		} 
		catch ( Exception e ) 
		{
			System.err.println( "ERROR : "+ e.getMessage() );
		}
		Solutions.c = c;
	}

	@After
	public void tearDown() throws Exception
	{
		c.close();
	}

	/** 
	 * constructor + setters/getters of Video
	 *
	@Test
	public void test1()
	{
		Video vid1 = new Video("GoT part 18", 16, "fantasy");
		assertEquals(16, vid1.getMinAge());
		String[] rev = vid1.getReviews();
		assertEquals(3, rev.length);
		assertEquals(0, vid1.getReviewCounter());
		assertEquals("fantasy", vid1.getCategory());
	}
*/
	/**
	 * check review mechanism: keep 3 most recent review, most recent last
	 * every review start with a rating, a value from 0 up to 9
	 *
	@Test
	public void test2()
	{
		Video vid1 = new Video("GoT part 18", 16, "fantasy");
		vid1.addReview("5 : same as 17");
		vid1.addReview("8 : Never boring");
		String[] rev = vid1.getReviews();
		assertEquals(2, vid1.getReviewCounter());
		assertTrue(rev[1].equals("8 : Never boring"));
		vid1.addReview("3 : I prefer part 2");
		vid1.addReview("6 : Oh no... part 1 was the max");
		rev = vid1.getReviews();
		assertEquals(3, rev.length);
		assertTrue(rev[0].equals("8 : Never boring"));
		assertTrue(rev[2].equals("6 : Oh no... part 1 was the max"));
	}
*/	
	/**
	 * check constructor of VODSystem + basic functionality find video by title
	 *
	@Test
	public void test3()
	{
		VODSystem vod1 = new VODSystem("www.vod.net");
		assertEquals("www.vod.net", vod1.getUrl());
		Video vid1 = new Video("GoT part 18", 16, "fantasy");
		Video vid2 = new Video("Bambi", 0, "disney");
		Video vid3 = new Video("Mission Impossible 2", 12, "thriller");
		vod1.addVideo(vid1);
		vod1.addVideo(vid2);
		vod1.addVideo(vid3);
		assertEquals(3, vod1.getNrOfVideos());
		assertNull(vod1.findVideo("The Missing"));
		assertSame(vid2, vod1.findVideo("Bambi"));
	}
*/	 
	/**
	 * check constructor  and getters of Client
	 *
	@Test
	public void test4()
	{
		Client cli1 = new Client(LocalDate.of(2007, 1, 20));
		assertEquals(0, cli1.getId());
		assertEquals(0, cli1.getNumberOfRentedVideos());
		assertEquals(LocalDate.of(2007, 1, 20), cli1.getBirthdate());
	}
*/
	/**
	 * check registering client before they can rent a video
	 * clients cannot register twice
	 *
	@Test
	public void test5()
	{
		VODSystem vod1 = new VODSystem("www.vod.net");
		Video vid1 = new Video("GoT part 18", 16, "fantasy");
		Video vid2 = new Video("Bambi", 0, "disney");
		Video vid3 = new Video("Mission Impossible 2", 12, "thriller");
		vod1.addVideo(vid1);
		vod1.addVideo(vid2);
		vod1.addVideo(vid3);
		Client cli1 = new Client(LocalDate.of(2007, 1, 20));
		assertFalse(vod1.rentVideo(cli1, "Bambi", LocalDate.now()));
		assertTrue(vod1.registerClient(cli1));
		assertTrue(vod1.rentVideo(cli1, "Bambi", LocalDate.now()));
		assertFalse(vod1.registerClient(cli1));
	}
*/	 
	/**
	 * check age restrictions when renting a video (age client >= minimum age of video)
	 *
	@Test
	public void test6()
	{
		VODSystem vod1 = new VODSystem("www.vod.net");
		Video vid1 = new Video("GoT part 18", 16, "fantasy");
		Video vid2 = new Video("Bambi", 0, "disney");
		Video vid3 = new Video("Mission Impossible 2", 12, "thriller");
		vod1.addVideo(vid1);
		vod1.addVideo(vid2);
		vod1.addVideo(vid3);
		assertEquals(3, vod1.getNrOfVideos());
		Client cli1 = new Client(LocalDate.of(2006, 1, 25));
		assertTrue(vod1.registerClient(cli1));
		assertFalse(vod1.rentVideo(cli1, "Mission Impossible 2", LocalDate.now()));
		assertTrue(vod1.rentVideo(cli1, "Mission Impossible 2", LocalDate.of(2018, 1, 26)));
	}
*/	 
	/**
	 * check the possibility to remove all videos which have not been rented yet
	 *
	@Test
	public void test7()
	{
		VODSystem vod1 = new VODSystem("www.vod.net");
		Video vid1 = new Video("GoT part 18", 16, "fantasy");
		Video vid2 = new Video("Bambi", 0, "disney");
		Video vid3 = new Video("Mission Impossible 2", 12, "thriller");
		vod1.addVideo(vid1);
		vod1.addVideo(vid2);
		vod1.addVideo(vid3);
		assertEquals(3, vod1.getNrOfVideos());
		Client cli1 = new Client(LocalDate.of(2005, 1, 25));
		assertTrue(vod1.registerClient(cli1));
		assertTrue(vod1.rentVideo(cli1, "Mission Impossible 2", LocalDate.now()));
		Client cli2 = new Client(LocalDate.of(2000, 10, 2));
		assertTrue(vod1.registerClient(cli2));
		assertTrue(vod1.rentVideo(cli2, "Mission Impossible 2", LocalDate.now()));
		assertTrue(vod1.rentVideo(cli2, "GoT part 18", LocalDate.now()));
		ArrayList<Video> result = vod1.removeUnrentedVideos();
		assertEquals(1, result.size());
		assertSame(vid2, result.get(0));
		}
*/	 
	/**
	 * check the possibility to populate clients from the Database
	 * use the ID from the DB in stead of the one generated by registerClient
	 * class String has ways to split up dd/mm/yyyy in different fields
	 * class Integer can convert String into int values
	 *
	@Test
	public void test8()
	{
		VODSystem vod1 = new VODSystem("www.vod.net");
		vod1.ClientsFromDB("VODSystem.db");
		assertEquals(4, vod1.getNrOfClients()); 
		Client cli = vod1.findClient(12);
		assertEquals(LocalDate.of(2002, 1, 6), cli.getBirthdate());
	}
*/	
	/**
	 * Query: how many videos has client with id = 3 rented
	 * You may try directly using SQLiteStudio but afterwards
	 * implement this query in the method Query1() of Queries
	 *
	@Test
	public void test9()
	{
		try
		{
		Queries q1 = new Queries(c);
		assertTrue(Solutions.checkResultSets(q1.query1(), Solutions.Query1()));
		}
		catch (SQLException sqle)
		{
			System.err.println( "ERROR : "+ sqle.getMessage() );
			fail("An exception occurred during the execution of your query, check the error message in the terminal");
		}
	}
*/	
	/**
	 * Query: show the birth date of clients which have already rented a video and are born in January 
	 * Dates in SQLite are strings in the format dd/mm/yyyy
	 * You may try directly using SQLiteStudio but afterwards
	 * implement this query in the method Query2() of Queries
	 *
	@Test
	public void test10()
	{
		try
		{
		Queries q1 = new Queries(c);
		assertTrue(Solutions.checkResultSets(q1.query2(), Solutions.Query2()));
		}
		catch (SQLException sqle)
		{
			System.err.println( "ERROR : "+ sqle.getMessage() );
			fail("An exception occurred during the execution of your query, check the error message in the terminal");
		}
	}
*/	
	/**
	 * Query: show the titles of all videos which have already been rented at least 5 times
	 * most popular title first
	 * You may try directly using SQLiteStudio but afterwards
	 * implement this query in the method Query3() of Queries
	 *
	@Test
	public void test11()
	{
		try
		{
		Queries q1 = new Queries(c);
		assertTrue(Solutions.checkResultSets(q1.query3(), Solutions.Query3()));
		}
		catch (SQLException sqle)
		{
			System.err.println( "ERROR : "+ sqle.getMessage() );
			fail("An exception occurred during the execution of your query, check the error message in the terminal");
		}
	}
*/	
	
	/**
	 * Return an alphabetical sorted list of all distinct video categories rented by a certain client
	 *
	@Test
	public void test12()
	{
		VODSystem vod1 = new VODSystem("www.vod.net");
		Video vid1 = new Video("GoT part 18", 16, "fantasy");
		Video vid2 = new Video("Bambi", 0, "disney");
		Video vid3 = new Video("Mission Impossible 2", 12, "thriller");
		Video vid4 = new Video("Mission Impossible 3", 12, "thriller");
		vod1.addVideo(vid1);
		vod1.addVideo(vid2);
		vod1.addVideo(vid3);
		vod1.addVideo(vid4);
		assertEquals(4, vod1.getNrOfVideos());
		Client cli1 = new Client(LocalDate.of(2000, 1, 25));
		assertTrue(vod1.registerClient(cli1));
		assertTrue(vod1.rentVideo(cli1, "Mission Impossible 2", LocalDate.now()));
		Client cli2 = new Client(LocalDate.of(2000, 10, 2));
		assertTrue(vod1.registerClient(cli2));
		assertTrue(vod1.rentVideo(cli2, "Mission Impossible 2", LocalDate.now()));
		assertTrue(vod1.rentVideo(cli2, "GoT part 18", LocalDate.now()));
		assertTrue(vod1.rentVideo(cli1, "Mission Impossible 3", LocalDate.of(2017, 12, 26)));
		assertTrue(vod1.rentVideo(cli1, "GoT part 18", LocalDate.of(2018, 1, 3)));
		assertNull(vod1.findCategoriesRentedBy(77));
		ArrayList<String> result = vod1.findCategoriesRentedBy(cli1.getId());
		assertEquals(2, result.size());
		assertEquals("fantasy", result.get(0));
		assertEquals("thriller", result.get(1));
	}
*/
	/**
	 * return the video with the highest average rating
	 * take only into account videos with reviews
	 *
	@Test
	public void test13()
	{
		VODSystem vod1 = new VODSystem("www.vod.net");
		Video vid1 = new Video("GoT part 18", 16, "fantasy");
		Video vid2 = new Video("Bambi", 0, "disney");
		Video vid3 = new Video("Mission Impossible 2", 12, "thriller");
		Video vid4 = new Video("Mission Impossible 3", 12, "thriller");
		vod1.addVideo(vid1);
		vod1.addVideo(vid2);
		vod1.addVideo(vid3);
		vod1.addVideo(vid4);
		assertNull(vod1.highestRatedVideo());
		vid1.addReview("9 : wooooow");
		vid3.addReview("3 : not impressed");
		vid3.addReview("8 : better than 1");
		vid1.addReview("1 : try to forget as quick as possible");
		assertSame(vid3, vod1.highestRatedVideo());
	}
*/
}
