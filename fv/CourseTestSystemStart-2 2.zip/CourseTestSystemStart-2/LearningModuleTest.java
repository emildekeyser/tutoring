import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class LearningModuleTest
{
    Connection c = null;

    @Before
    public void setUp() throws Exception
    {
        try 
        {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:CourseTestSystem.db");
        } 
        catch ( Exception e ) 
        {
            System.err.println( "ERROR : "+ e.getMessage() );
        }
        Solutions.c = c;
    }

    @After
    public void tearDown() throws Exception
    {
        c.close();
    }

    /** 
     * constructor + setters/getters of CourseTest
     *
    @Test
    public void test1()
    {
        CourseTest ctest1 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        assertEquals(1, ctest1.getNumber());
        char[] correct = ctest1.getCorrectAnswers();
        assertEquals('A', correct[0]);
        assertEquals('C', correct[2]);
    }
*/
    /** 
     * check scoring mechanism
     *
    @Test
    public void test2()
    {
        CourseTest ctest1 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        assertEquals(2, ctest1.calculateScore('A', 'D', 'C'));
        assertEquals(0, ctest1.calculateScore('X', ' ', 'A'));
        assertEquals(3, ctest1.calculateScore('A', 'B', 'C'));
    }
*/  
    /**
     * check constructor of Course + basic functionality
     *
    @Test
    public void test3()
    {
        Course c1 = new Course("T2OOPDB");
        assertEquals("T2OOPDB", c1.getCourseCode());
        CourseTest ctest1 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        CourseTest ctest2 = new CourseTest(2, "relations", 'A', 'B', 'C');
        CourseTest ctest3 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        assertTrue(c1.addTest(ctest1));
        assertTrue(c1.addTest(ctest2));
        assertFalse(c1.addTest(ctest3));
        assertEquals(2, c1.getNrOfTests());
        assertNull(c1.findTest(0));
        assertSame(ctest2, c1.findTest(2));
    }
*/   
    /**
     * check constructor of Student
     *
    @Test
    public void test4()
    {
        Student stud1 = new Student("First Last");
        assertEquals(0, stud1.getTotalNumberOfTrialsTaken());
    }
*/
    /**
     * check taking test by student, every student needs to start with test1
     *
    @Test
    public void test5()
    {
        Course c1 = new Course("T2OOPDB");
        assertEquals("T2OOPDB", c1.getCourseCode());
        CourseTest ctest1 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        CourseTest ctest2 = new CourseTest(2, "relations", 'B', 'B', 'C');
        CourseTest ctest3 = new CourseTest(3, "collections", 'A', 'A', 'C');
        assertTrue(c1.addTest(ctest1));
        assertTrue(c1.addTest(ctest2));
        assertTrue(c1.addTest(ctest3));
        assertEquals(3, c1.getNrOfTests());
        Student stud1 = new Student("First Last");
        c1.addStudent(stud1);
        assertNull(c1.findStudent("Not Existing"));
        assertSame(stud1, c1.findStudent("First Last"));
        assertFalse(c1.takeTest(stud1, 3, 'A', 'A', 'C'));
        assertTrue(c1.takeTest(stud1, 1, 'A', 'A', 'C'));
        assertEquals(2, stud1.getBestResultForTest(1));
        assertEquals(-1, stud1.getBestResultForTest(0));
    }
*/   
    /**
     * check taking test by student
     * order is important, next test can only be taken if previous test was succesful (score = 3)
     *
    @Test
    public void test6()
    {
        Course c1 = new Course("T2OOPDB");
        assertEquals("T2OOPDB", c1.getCourseCode());
        CourseTest ctest1 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        CourseTest ctest2 = new CourseTest(2, "relations", 'B', 'B', 'C');
        CourseTest ctest3 = new CourseTest(3, "collections", 'A', 'A', 'C');
        assertTrue(c1.addTest(ctest1));
        assertTrue(c1.addTest(ctest2));
        assertTrue(c1.addTest(ctest3));
        assertEquals(3, c1.getNrOfTests());
        Student stud1 = new Student("First Last");
        c1.addStudent(stud1);
        assertTrue(c1.takeTest(stud1, 1, 'A', 'A', 'C'));
        assertFalse(c1.takeTest(stud1, 2, 'A', 'A', 'C'));
        assertTrue(c1.takeTest(stud1, 1, 'A', 'B', 'C'));
        assertTrue(c1.takeTest(stud1, 2, 'A', 'A', 'C'));
        assertEquals(3, stud1.getBestResultForTest(1));
        assertEquals(1, stud1.getBestResultForTest(2));
        assertEquals(3, stud1.getTotalNumberOfTrialsTaken());
    }
*/   
    /**
     * check the possibility to remove all students from a course who have not taken any test yet
     *
    @Test
    public void test7()
    {
        Course c1 = new Course("T2OOPDB");
        assertEquals("T2OOPDB", c1.getCourseCode());
        CourseTest ctest1 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        CourseTest ctest2 = new CourseTest(2, "relations", 'B', 'B', 'C');
        CourseTest ctest3 = new CourseTest(3, "collections", 'A', 'A', 'C');
        assertTrue(c1.addTest(ctest1));
        assertTrue(c1.addTest(ctest2));
        assertTrue(c1.addTest(ctest3));
        assertEquals(3, c1.getNrOfTests());
        Student stud1 = new Student("Java Python");
        c1.addStudent(stud1);
        assertTrue(c1.takeTest(stud1, 1, 'A', 'A', 'C'));
        assertTrue(c1.takeTest(stud1, 1, 'A', 'B', 'C'));
        assertTrue(c1.takeTest(stud1, 2, 'A', 'A', 'C'));
        Student stud2 = new Student("C Cobol");
        c1.addStudent(stud2);
        assertTrue(c1.takeTest(stud2, 1, 'A', 'A', 'C'));
        Student stud3 = new Student("Lazy Guy");
        c1.addStudent(stud3);
        Student stud4 = new Student("Miss Wrong");
        c1.addStudent(stud4);
        assertTrue(c1.takeTest(stud4, 1, 'A', 'B', 'C'));
        Student stud5 = new Student("Miss Confused");
        c1.addStudent(stud5);
        assertFalse(c1.takeTest(stud5, 3, 'A', 'B', 'C'));
        ArrayList<Student> result = c1.removeInactiveStudents();
        assertEquals(2, result.size());
        assertTrue(result.contains(stud3));
        assertTrue(result.contains(stud5));
    }
*/   
    /**
     * check the possibility to process test results saved in a file with format
     * - student name
     * - test number
     * - answer1
     * - answer2
     * - answer3
     *
    @Test
    public void test8()
    {
        Course c1 = new Course("T2OOPDB");
        assertEquals("T2OOPDB", c1.getCourseCode());
        CourseTest ctest1 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        CourseTest ctest2 = new CourseTest(2, "relations", 'B', 'B', 'C');
        CourseTest ctest3 = new CourseTest(3, "collections", 'A', 'A', 'C');
        assertTrue(c1.addTest(ctest1));
        assertTrue(c1.addTest(ctest2));
        assertTrue(c1.addTest(ctest3));
        assertEquals(5, c1.populateFromFile("results.txt"));
    }
*/  
    /**
     * Query: how many different students have already taken test with testId = 1
     * You may try directly using SQLiteStudio but afterwards
     * implement this query in the method Query1() of Queries
     *
    @Test
    public void test9()
    {
        try
        {
        Queries q1 = new Queries(c);
        assertTrue(Solutions.checkResultSets(q1.query1(), Solutions.Query1()));
        }
        catch (SQLException sqle)
        {
            System.err.println( "ERROR : "+ sqle.getMessage() );
            fail("An exception occurred during the execution of your query, check the error message in the terminal");
        }
    }
*/  
    /**
     * Query: show the name of all the available test together with the code of the course
     * You may try directly using SQLiteStudio but afterwards
     * implement this query in the method Query2() of Queries
     *
    @Test
    public void test10()
    {
        try
        {
        Queries q1 = new Queries(c);
        assertTrue(Solutions.checkResultSets(q1.query2(), Solutions.Query2()));
        }
        catch (SQLException sqle)
        {
            System.err.println( "ERROR : "+ sqle.getMessage() );
            fail("An exception occurred during the execution of your query, check the error message in the terminal");
        }
    }
*/  
    /**
     * Query: show the name of the test and the total number of trials taken ordered by
     * difficulty (most trials first) Show only those with at least 2 trials
     * You may try directly using SQLiteStudio but afterwards
     * implement this query in the method Query3() of Queries
     *
    @Test
    public void test11()
    {
        try
        {
        Queries q1 = new Queries(c);
        assertTrue(Solutions.checkResultSets(q1.query3(), Solutions.Query3()));
        }
        catch (SQLException sqle)
        {
            System.err.println( "ERROR : "+ sqle.getMessage() );
            fail("An exception occurred during the execution of your query, check the error message in the terminal");
        }
    }
*/  
    
    /**
     * Find the most difficult test (=test with on average over all students involved most trials to get a score of 3)
     * if multiple found, return first one found
     *
    @Test
    public void test12()
    {
        Course c1 = new Course("T2OOPDB");
        assertEquals("T2OOPDB", c1.getCourseCode());
        CourseTest ctest1 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        CourseTest ctest2 = new CourseTest(2, "relations", 'B', 'B', 'C');
        CourseTest ctest3 = new CourseTest(3, "collections", 'A', 'A', 'C');
        assertTrue(c1.addTest(ctest1));
        assertTrue(c1.addTest(ctest2));
        assertTrue(c1.addTest(ctest3));
        assertEquals(3, c1.getNrOfTests());
        Student stud1 = new Student("Java Python");
        c1.addStudent(stud1);
        assertTrue(c1.takeTest(stud1, 1, 'A', 'B', 'C'));
        assertTrue(c1.takeTest(stud1, 2, 'A', 'B', 'C'));
        assertTrue(c1.takeTest(stud1, 2, 'A', 'A', 'C'));
        Student stud2 = new Student("C Cobol");
        c1.addStudent(stud2);
        assertTrue(c1.takeTest(stud2, 1, 'A', 'B', 'C'));
        Student stud3 = new Student("Lazy Guy");
        c1.addStudent(stud3);
        assertTrue(c1.takeTest(stud3, 1, 'A', 'B', 'C'));
        assertTrue(c1.takeTest(stud3, 2, 'B', 'B', 'B'));
        assertTrue(c1.takeTest(stud3, 2, 'B', 'B', 'C'));
        assertTrue(c1.takeTest(stud3, 3, 'B', 'A', 'C'));
        Student stud4 = new Student("Miss Wrong");
        c1.addStudent(stud4);
        assertTrue(c1.takeTest(stud4, 1, 'A', 'B', 'C'));
        Student stud5 = new Student("Miss Confused");
        c1.addStudent(stud5);
        assertTrue(c1.takeTest(stud5, 1, 'A', 'B', 'A'));
        assertTrue(c1.takeTest(stud5, 1, 'A', 'B', 'C'));
        assertSame(ctest2, c1.findMostDifficultTest());
    }
*/
    /**
     * create a sorted list of all student names who will be invited for an extra sessions
     * = students who have not yet successfully finished all tests or
     * students who need more than 3 trials for at least 1 test
     *
    @Test
    public void test13()
    {
        Course c1 = new Course("T2OOPDB");
        assertEquals("T2OOPDB", c1.getCourseCode());
        CourseTest ctest1 = new CourseTest(1, "OO syntax", 'A', 'B', 'C');
        CourseTest ctest2 = new CourseTest(2, "relations", 'B', 'B', 'C');
        CourseTest ctest3 = new CourseTest(3, "collections", 'A', 'A', 'C');
        assertTrue(c1.addTest(ctest1));
        assertTrue(c1.addTest(ctest2));
        assertTrue(c1.addTest(ctest3));
        assertEquals(3, c1.getNrOfTests());
        Student stud1 = new Student("Java Python");
        c1.addStudent(stud1);
        assertTrue(c1.takeTest(stud1, 1, 'A', 'B', 'C'));
        assertTrue(c1.takeTest(stud1, 2, 'A', 'B', 'C'));
        assertTrue(c1.takeTest(stud1, 2, 'A', 'A', 'C'));
        assertTrue(c1.takeTest(stud1, 2, 'B', 'B', 'C'));
        assertTrue(c1.takeTest(stud1, 3, 'A', 'A', 'C'));
        Student stud2 = new Student("C Cobol");
        c1.addStudent(stud2);
        assertTrue(c1.takeTest(stud2, 1, 'A', 'B', 'C'));
        Student stud3 = new Student("Lazy Guy");
        c1.addStudent(stud3);
        assertTrue(c1.takeTest(stud3, 1, 'A', 'B', 'C'));
        assertTrue(c1.takeTest(stud3, 2, 'B', 'B', 'B'));
        assertTrue(c1.takeTest(stud3, 2, 'B', 'B', 'C'));
        assertTrue(c1.takeTest(stud3, 3, 'A', 'A', 'C'));
        Student stud4 = new Student("Miss Wrong");
        c1.addStudent(stud4);
        assertTrue(c1.takeTest(stud4, 1, 'A', 'B', 'C'));
        Student stud5 = new Student("Miss Confused");
        c1.addStudent(stud5);
        assertTrue(c1.takeTest(stud5, 1, 'A', 'B', 'A'));
        assertTrue(c1.takeTest(stud5, 1, 'A', 'B', 'C'));
        ArrayList<String> result = c1.namesToInvite();
        assertEquals(3, result.size());
        assertEquals("C Cobol", result.get(0));
        assertEquals("Miss Wrong", result.get(2));
    }
*/
}
