import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Course
{
}
/*
 
		try
		{
			Scanner sc = new Scanner(new File(fileName));
			while (sc.hasNext()) 
			{	
			}
			sc.close();
		}
		catch (FileNotFoundException fnfe)
		{
			System.out.println("File " + fileName + " not found");
		}
*/

