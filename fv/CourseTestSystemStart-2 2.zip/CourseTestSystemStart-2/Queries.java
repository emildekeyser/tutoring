import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;

public class Queries
{
    private Connection c;

    public Queries(Connection c)
    {
        this.c = c;
    }

    /**
     * query where you need to find how many students tried the test with testId 1 
     *
    public ResultSet query1() throws SQLException
    {
    Statement stmt = c.createStatement();
    String q = "...";
    ResultSet rs = stmt.executeQuery( q );
    return rs;
    }
*/

    /**
     * query where you generate an overview of all test names together with the code of the
     * corresponding course
     *
    public ResultSet query2() throws SQLException
    {
        Statement stmt = c.createStatement();
        String q = "...";
        ResultSet rs = stmt.executeQuery( q );
        return rs;
    }
*/

    /**
     * query where you want to get a list with all tests together with the total number of trials for this
     * test. The list is sorted by difficulty most trials first). Show only test which need more than 2 trials
     *

    public ResultSet query3() throws SQLException
    {
        Statement stmt = c.createStatement();
        String q = "...";
        ResultSet rs = stmt.executeQuery( q );
        return rs;
    }
*/
}
