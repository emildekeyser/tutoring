import java.io.File;
import java.util.Scanner;
import java.sql.*;

public class Club 
{
/*		try
		{
			Scanner sc = new Scanner(new File(filename));
			while (sc.hasNext())
			{
			}
			sc.close();
		}
		catch(Exception e){};
		*/

	/*
	 Connection c = null;
		try 
		{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:"+dbName);
			System.out.println("Opened database successfully");

			Statement stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery( ... );
			while ( rs.next() ) 
			{
			}
			rs.close();
			stmt.close();
			c.close();
		} 
		catch ( Exception e ) 
		{
			System.err.println( "ERROR : "+ e.getMessage() );
		}
		*/
}
