import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.io.*;

public class SatMonTest
{
	Connection c = null;

	@Before
	public void setUp() throws Exception
	{
		try 
		{
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:Satmon.db");
		} 
		catch ( Exception e ) 
		{
			System.err.println( "ERROR : "+ e.getMessage() );
		}
		Solutions.c = c;
	}

	@After
	public void tearDown() throws Exception
	{
		c.close();
	}

	/**
	 * checks constructor and getters of Question
	 *
    @Test
    public void test1() {
        String[] options = new String[3];
        options[0] = "Yes";
        options[1] = "No opinion";
        options[2] = "No";
        String quest1Text = "Are you happy now?";
        Question quest1 = new Question("gen01", quest1Text, options);
        assertTrue(quest1.getText().equals(quest1Text));
        assertNotNull(quest1.getOptions());
        assertEquals(3, quest1.getOptions().length);
        assertEquals("gen01", quest1.getCode());
    }
*/
	/**
	 * checks if an option is valid for a certain question
	 *
    @Test
    public void test2() {
        String[] options = new String[3];
        options[0] = "Yes";
        options[1] = "No opinion";
        options[2] = "No";
        String quest1Text = "Are you happy now?";
        Question quest1 = new Question("gen01", quest1Text, options);
        assertTrue(quest1.checkValidOption("No opinion"));
        assertFalse(quest1.checkValidOption(""));
        assertFalse(quest1.checkValidOption("No idea"));
    }
*/
    /**
     * checks constructor and getter of inhabitant
     *
    @Test
    public void test3() 
    {
        LocalDate date1 = LocalDate.of(1939, 7, 21);
        Inhabitant inhab1 = new Inhabitant("Neil", "19390721-123", date1);

        assertEquals("19390721-123", inhab1.getNationalNumber());
        assertEquals(0, inhab1.getAnsweredQuestionNrs().size());
        assertEquals(0, inhab1.getChoosenOption().size());
        assertEquals(date1, inhab1.getBirthDate());
    }
*/
    /**
     * checks constructor of SatisfactionMonitor + adding of questions
     **
    @Test
    public void test4() 
    {
        SatisfactionMonitor satmon = new SatisfactionMonitor("Happy to be old");
        assertEquals(0, satmon.getNrOfQuestions());
        String[] options = new String[3];
        options[0] = "Yes";
        options[1] = "No opinion";
        options[2] = "No";
        String quest1Text = "Are you happy now?";
        Question quest1 = new Question("gen01", quest1Text, options);
        satmon.addQuestion(quest1);
        String quest2Text = "Have you already been active today?";
        Question quest2 = new Question("gen02", quest2Text, options);
        satmon.addQuestion(quest2);
        assertEquals(2, satmon.getNrOfQuestions());
    }
*/
    /**
     * checks adding of inhabitants, no 2 inhabitants with same National Number are allowed
     **
    @Test
    public void test5() 
    {
        SatisfactionMonitor satmon = new SatisfactionMonitor("Happy to be old");
        assertEquals(0, satmon.getNrOfInhabitants());
        LocalDate date1 = LocalDate.of(1939, 7, 21);
        Inhabitant inhab1 = new Inhabitant("Neil", "19390721-123", date1);
        assertTrue(satmon.addInhabitant(inhab1));
        Inhabitant inhab2 = new Inhabitant("Linda", "19390721-088", date1);
        assertTrue(satmon.addInhabitant(inhab2));
        LocalDate date2 = LocalDate.of(1942, 5, 1);
        Inhabitant inhab3 = new Inhabitant("Neil", "19420501-123", date2);
        assertTrue(satmon.addInhabitant(inhab3));
        assertEquals(3, satmon.getNrOfInhabitants());
        Inhabitant inhab4 = new Inhabitant("NotAllowed", "19390721-088", date2);
        assertFalse(satmon.addInhabitant(inhab4));
        assertEquals(3, satmon.getNrOfInhabitants());
    }
*/    
    /**
     * checks the procedure of answering questions by inhabitants
     * only existing question numbers (=index in questions collection) with a valid option are accepted
     **
    @Test
    public void test6() 
    {
        SatisfactionMonitor satmon = new SatisfactionMonitor("Happy to be old");
        assertEquals(0, satmon.getNrOfQuestions());
        String[] options = new String[3];
        options[0] = "Yes";
        options[1] = "No opinion";
        options[2] = "No";
        String quest1Text = "Are you happy now?";
        Question quest1 = new Question("gen01", quest1Text, options);
        satmon.addQuestion(quest1);
        String quest2Text = "Have you already been active today?";
        Question quest2 = new Question("gen02", quest2Text, options);
        satmon.addQuestion(quest2);
        assertEquals(2, satmon.getNrOfQuestions());
        LocalDate date1 = LocalDate.of(1939, 7, 21);
        Inhabitant inhab1 = new Inhabitant("Neil", "19390721-123", date1);
        assertTrue(satmon.addInhabitant(inhab1));
        Inhabitant inhab2 = new Inhabitant("Linda", "19390721-088", date1);
        assertTrue(satmon.addInhabitant(inhab2));
        LocalDate date2 = LocalDate.of(1942, 5, 1);
        Inhabitant inhab3 = new Inhabitant("Neil", "19420501-123", date2);
        assertTrue(satmon.addInhabitant(inhab3));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab1, 1, "Yes"));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab1, 1, "Yes"));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab3, 0, "No"));
        assertFalse(satmon.inhabitantsAnswersQuestion(inhab1, 1, "invalid option"));
        assertFalse(satmon.inhabitantsAnswersQuestion(inhab3, 2, "No"));
    }
*/    
    /**
     * checks removing of questions starting with a certain substring
     **
    @Test
    public void test7() 
    {
        SatisfactionMonitor satmon = new SatisfactionMonitor("Happy to be old");
        assertEquals(0, satmon.getNrOfQuestions());
        String[] options = new String[3];
        options[0] = "Yes";
        options[1] = "No opinion";
        options[2] = "No";
        String quest1Text = "Are you happy now?";
        Question quest1 = new Question("gen01", quest1Text, options);
        satmon.addQuestion(quest1);
        String [] boolOptions = new String[2];
        boolOptions[0] = "true";
        boolOptions[1] = "false";
        Question quest2 = new Question("food01", "I liked the breakfast", boolOptions);
        satmon.addQuestion(quest2);
        Question quest3 = new Question("gen02", "Have you already been active today?", options);
        satmon.addQuestion(quest3);
        Question quest4 = new Question("health01", "Currently I have no fever", boolOptions);
        satmon.addQuestion(quest4);
        assertEquals(4, satmon.getNrOfQuestions());
        assertEquals(0, satmon.removeQuestionStartingWithCode("xyz"));
        assertEquals(2, satmon.removeQuestionStartingWithCode("gen"));
        assertEquals(0, satmon.removeQuestionStartingWithCode("gen"));
        assertEquals(2, satmon.getNrOfQuestions());
    }
*/    
    /**
     ** checks loading inhabitants from file
     **
    @Test
    public void test8()
    {
        SatisfactionMonitor satmon = new SatisfactionMonitor("Happy to be old");
        satmon.loadInhabitantsFromFile("inhabitants.txt");
        assertEquals(4, satmon.getNrOfInhabitants());
        assertTrue(satmon.getInhabitants().get(1).getName().equals("Donald Trup"));
           	
    }
	/*
	 * Query: How many questions can be answered by an option that begins with 'no'
	 * You may try directly using SQLiteStudio but afterwards
	 * implement this query in the method Query1() of Queries
	 */
	@Test
	public void test9()
	{
		try
		{
		Queries q1 = new Queries(c);
		assertTrue(Solutions.checkResultSets(q1.query1(), Solutions.Query1()));
		}
		catch (SQLException sqle)
		{
			System.err.println( "ERROR : "+ sqle.getMessage() );
		}
	}
	
	/*
	 * Query: show an alphabetical list of the names of all the inhabitants who answered a question on '2017-12-25'
	 * You may try directly using SQLiteStudio but afterwards
	 * implement this query in the method Query2() of Queries
	 *
	@Test
	public void test10()
	{
		try
		{
		Queries q1 = new Queries(c);
		assertTrue(Solutions.checkResultSets(q1.query2(), Solutions.Query2()));
		}
		catch (SQLException sqle)
		{
			System.err.println( "ERROR : "+ sqle.getMessage() );
		}
	}
*/	
	/*
	 * Query: Show a list of names of inhabitants together with the total number of questions they answered
	 * Show only those who answered more than 1 question, show first those with highest number of answer, when equal, sort alphabetical
	 * You may try directly using SQLiteStudio but afterwards
	 * implement this query in the method Query3() of Queries
	 *
	@Test
	public void test11()
	{
		try
		{
		Queries q1 = new Queries(c);
		assertTrue(Solutions.checkResultSets(q1.query3(), Solutions.Query3()));
		}
		catch (SQLException sqle)
		{
			System.err.println( "ERROR : "+ sqle.getMessage() );
		}
	}
	*/
    /**
     * checks removing all inhabitants older than a certain age given in years
     *
    @Test
    public void test12()
    {
        SatisfactionMonitor satmon = new SatisfactionMonitor("Happy to be old");
        assertEquals(0, satmon.getNrOfInhabitants());
        LocalDate date1 = LocalDate.of(1939, 7, 21);
        Inhabitant inhab1 = new Inhabitant("Neil", "19390721-123", date1);
        assertTrue(satmon.addInhabitant(inhab1));
        Inhabitant inhab2 = new Inhabitant("Linda", "19390721-088", date1);
        assertTrue(satmon.addInhabitant(inhab2));
        LocalDate date2 = LocalDate.of(1942, 5, 1);
        Inhabitant inhab3 = new Inhabitant("Neil", "19420501-123", date2);
        assertTrue(satmon.addInhabitant(inhab3));
        assertEquals(3, satmon.getNrOfInhabitants());
        LocalDate date3 = LocalDate.of(1940, 7, 21);
        Inhabitant inhab4 = new Inhabitant("Laura", "19400721-088", date3);
        assertTrue(satmon.addInhabitant(inhab4));
        ArrayList<Inhabitant> result = satmon.removeInhabitantsOlderThan(78);
        assertEquals(2, result.size());
        assertEquals(2, satmon.getNrOfInhabitants());
        result = satmon.removeInhabitantsOlderThan(77);
        assertEquals(1, result.size());
        assertEquals(1, satmon.getNrOfInhabitants());
      	
    }
*/
    /**
     * find the most satisfied inhabitant = the inhabitant who answered the most questions
     * and when equal number of questions, the inhabitant who answered most positive
     * assume options are always arranged from most positive to most negative
     *
    @Test
    public void test13()
    {
        SatisfactionMonitor satmon = new SatisfactionMonitor("Happy to be old");
        assertEquals(0, satmon.getNrOfInhabitants());
        LocalDate date1 = LocalDate.of(1939, 7, 21);
        Inhabitant inhab1 = new Inhabitant("Neil", "19390721-123", date1);
        assertTrue(satmon.addInhabitant(inhab1));
        Inhabitant inhab2 = new Inhabitant("Linda", "19390721-088", date1);
        assertTrue(satmon.addInhabitant(inhab2));
        LocalDate date2 = LocalDate.of(1942, 5, 1);
        Inhabitant inhab3 = new Inhabitant("Neil", "19420501-123", date2);
        assertTrue(satmon.addInhabitant(inhab3));
        String[] options = new String[3];
        options[0] = "Yes";
        options[1] = "No opinion";
        options[2] = "No";
        String quest1Text = "Are you happy now?";
        Question quest1 = new Question("gen01", quest1Text, options);
        satmon.addQuestion(quest1);
        String [] boolOptions = new String[2];
        boolOptions[0] = "true";
        boolOptions[1] = "false";
        Question quest2 = new Question("food01", "I liked the breakfast", boolOptions);
        satmon.addQuestion(quest2);
        Question quest3 = new Question("gen02", "Have you already been active today?", options);
        satmon.addQuestion(quest3);
        Question quest4 = new Question("health01", "Currently I have no fever", boolOptions);
        satmon.addQuestion(quest4);
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab1, 0, "Yes"));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab1, 1, "false"));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab1, 3, "false"));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab2, 1, "true"));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab2, 3, "true"));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab3, 2, "Yes"));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab3, 1, "true"));
        assertTrue(satmon.inhabitantsAnswersQuestion(inhab3, 3, "false"));
        assertSame(inhab3, satmon.findMostSatisfiedInhabitant());
    	
    }
*/   
}