public class Inhabitant
{
}
