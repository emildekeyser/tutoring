import java.util.Scanner;
import java.io.File;

public class SatisfactionMonitor
{
}
/*
        try {
            Scanner scanner = new Scanner(new File(filename));
            while(scanner.hasNext()) {
            }
        }
        catch(Exception e) {
            System.out.println("Error");
        }
    }
*/
